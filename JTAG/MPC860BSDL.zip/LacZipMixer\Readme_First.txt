
Note the enclosed�tool collateral files may contain references to Motorola, Inc.  
All information contained in this file is now the property of Freescale Semiconductor, Inc.
�
If you have any questions or comments related to the information contained in theses files, contact the Freescale Semiconductor Technical Information Center.  Contact information follows: 

Worldwide Access:
Internet: www.freescale.com
E-mail:support@freescale.com

Technical Helpline:			www.freescale.com/support
Send your technical questions directly to our team of product specialists. After login, you may request information for a new service request, or View/Update your existing requests. If you are having problems logging into our site or would like to speak to one of our representatives, call our Technical Information Center at the phone numbers listed below.

Telephone, Fax, and E-mail Contacts:
North and South America:        	      Phone:	+1-800-521-6274 or +1-480-768-2130  
(6 am - 5 pm Mountain Standard Time)
                                              Fax:	+1-480-768-2131 
                                              E-mail: 	support@freescale.com

Europe, Middle East and Africa		      Phone: 	+44 1296 380 456 (English)
(9 am - 5 pm Central European Time)		        +46 8 52200080 (English)
                                                  	+49 89 92103 559 (German) 
                                                 	+33 1 69 35 48 48 (French) 
                                              Fax:   	+49 89 92103 466(German and English)
                                              E-mail:  	support@freescale.com
       
Asia/Pacific:*				      Phone:  	+800 2666 8080* (Toll Free within A/P)
(9 am - 5 pm Hong Kong)			             	+800 990 8188 (Toll Free within China)
India:						        +000 800 852 1155 (Toll Free within India)
                                              Fax:   	+852 2661 7736(Chinese and English)
                                              E-mail: 	support.asia@freescale.com
       
       
Japan:					      Phone:	0120 191 014(Toll Free: Domestic only)
(8 am - 5 pm Tokyo)			      Fax:	0120 191 060(Toll Free: Domestic only)
                                              E-mail:	support.japan@freescale.com
                                              Internet: www.freescale.co.jp
       
*Countries covered within Asia/Pacific are: China, Taiwan, South Korea, Macau, Malaysia, Singapore, Thailand, Australia and New Zealand.

Readme_First file created on 22 November 2005.
